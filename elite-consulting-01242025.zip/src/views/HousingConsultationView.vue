<script setup>
import HousingCoverSection from'../components/HousingConsultationTab/HousingCoverSection.vue';
import WhatisHousing from '../components/HousingConsultationTab/WhatisHousing.vue';
import HouseTypeCard1 from '../components/HousingConsultationTab/HouseTypeCard1.vue';
import HouseTypeCard2 from '../components/HousingConsultationTab/HouseTypeCard2.vue';
import HouseTypeCard3 from '../components/HousingConsultationTab/HouseTypeCard3.vue';
import WhoDoesHelp from '../components/HousingConsultationTab/WhoDoesHelp.vue';
import PleaseConatct from '../components/HousingConsultationTab/PleaseConatct.vue';
import Contact from '../components/Contact.vue';
import Footer from '../components/Footer.vue';
</script>
<template>
    <div>
        <HousingCoverSection />
        <WhatisHousing />
        <HouseTypeCard1 />
        <HouseTypeCard2 />
        <HouseTypeCard3 />
        <WhoDoesHelp />
        <PleaseConatct />
        <Contact />
        <Footer />

    </div>
</template>